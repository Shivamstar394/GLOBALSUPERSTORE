-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema new_schema1
-- -----------------------------------------------------
-- Orders.CustomerID → Customers.CustomerID
-- 
-- Sales.OrderID → Orders.OrderID
-- 
-- Sales.ProductID → Products.ProductID
-- 
-- OrderRegion.OrderID → Orders.OrderID
-- 
-- OrderRegion.RegionID → Region.RegionID

-- -----------------------------------------------------
-- Schema new_schema1
--
-- Orders.CustomerID → Customers.CustomerID
-- 
-- Sales.OrderID → Orders.OrderID
-- 
-- Sales.ProductID → Products.ProductID
-- 
-- OrderRegion.OrderID → Orders.OrderID
-- 
-- OrderRegion.RegionID → Region.RegionID
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `new_schema1` ;
USE `new_schema1` ;

-- -----------------------------------------------------
-- Table `new_schema1`.`customers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `new_schema1`.`customers` (
  `CustomersID` INT NOT NULL AUTO_INCREMENT,   -- Make sure NOT NULL is specified here
  `CustomerName` VARCHAR(100) NOT NULL,
  `Segment` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`CustomersID`)
) ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `new_schema1`.`products`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `new_schema1`.`products` (
  `ProductID` INT NULL AUTO_INCREMENT,
  `ProductName` VARCHAR(100) NOT NULL,
  `Category` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`ProductID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `new_schema1`.`region`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `new_schema1`.`region` (
  `RegionID` INT NULL AUTO_INCREMENT,
  `Country` VARCHAR(50) NOT NULL,
  `State` VARCHAR(50) NOT NULL,
  `City` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`RegionID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `new_schema1`.`sales`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `new_schema1`.`sales` (
  `SalesID` INT NULL AUTO_INCREMENT,
  `OrderID` INT NULL,
  `ProductID` INT NULL,
  `Quantity` INT NOT NULL,
  `SalesAmount` DECIMAL(10,2) NOT NULL,
  `Profit` DECIMAL(10,2) NULL,
  `ShippingCost` DECIMAL(10,2) NULL,
  PRIMARY KEY (`SalesID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `new_schema1`.`orders`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `new_schema1`.`orders` (
  `OrderIdD` INT NULL AUTO_INCREMENT,
  `ProductID` INT NOT NULL,
  `CustomerID` INT NULL,
  `customers_CustomersID` INT NOT NULL,
  `products_ProductID` INT NOT NULL,
  `region_RegionID` INT NOT NULL,
  `sales_SalesID` INT NOT NULL,
  PRIMARY KEY (`OrderIdD`, `customers_CustomersID`, `products_ProductID`, `region_RegionID`, `sales_SalesID`),
  INDEX `fk_orders_customers_idx` (`customers_CustomersID` ASC) VISIBLE,
  INDEX `fk_orders_products1_idx` (`products_ProductID` ASC) VISIBLE,
  INDEX `fk_orders_region1_idx` (`region_RegionID` ASC) VISIBLE,
  INDEX `fk_orders_sales1_idx` (`sales_SalesID` ASC) VISIBLE,
  CONSTRAINT `fk_orders_customers`
    FOREIGN KEY (`customers_CustomersID`)
    REFERENCES `new_schema1`.`customers` (`CustomersID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_orders_products1`
    FOREIGN KEY (`products_ProductID`)
    REFERENCES `new_schema1`.`products` (`ProductID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_orders_region1`
    FOREIGN KEY (`region_RegionID`)
    REFERENCES `new_schema1`.`region` (`RegionID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_orders_sales1`
    FOREIGN KEY (`sales_SalesID`)
    REFERENCES `new_schema1`.`sales` (`SalesID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `new_schema1`.`OrderRegion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `new_schema1`.`OrderRegion` (
  `OrderID` INT NULL,
  `RegionID` INT NULL)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
